import React, {useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
} from 'react-native';

import firebase from 'firebase/app';

function ShoppingForm({ navigation }) {


  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const ShoppingForm = () => {
    firebase
      .auth()
      .signInWithEmailAndPassword(email, password)
      .then((userCredential) => {
        alert('Sign In successfully');
        {
          navigation.navigate('Home');
        }
        var user = userCredential.user;
      })
      .catch((error) => {
        var errorCode = error.code;
        var errorMessage = error.message;
      });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.Text2}>LOGIN</Text>

      <TextInput
        placeholder='Email'
        style={styles.TextInput}
        onChangeText={(email) => setEmail(email)}
      />
      <TextInput
        placeholder='Password'
        style={styles.TextInput}
        onChangeText={(password) => setPassword(password)}
      />
      <TouchableOpacity style={styles.paragraph}>
        <Text style={styles.Text3} onPress={ShoppingForm}>
          Login
        </Text>
      </TouchableOpacity>

      <Text style={styles.Text}>
        Dont have an account ?
        <TouchableOpacity
          style={styles.signup}
          onPress={() => navigation.navigate('')}>
         <Text style={styles.text}> Sign up</Text>
    
            </TouchableOpacity>
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    flexShrink: '0',
    marginLeft: '20%',
    marginRight: '20%',
    marginTop: '20%',
  },
  paragraph: {
      marginTop:20,
    fontSize:15,
    marginLeft:70,
    borderRadius:40,
    borderWidth:1,
    alignSelf:'center',
    backgroundColor:'orange',
    fontWeight:'bold',
    width:200,
    height:50
   
    
  },
  TextInput: {
    borderWidth: '1px',
    width: '300px',
    height: '40px',
    paddingLeft: '10px',
    marginBottom: '10px',
    boxShadow: '1px 1px 2px rgba(0,0,0,0.5)',
    borderRadius:40,
     backgroundColor:'orange',
    
  },
  Text2: {
    margin: 25,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: 'arial black',
    paddingTop: '5%', 
  },
  Text3:{
    marginLeft:70,
    marginTop:12,
    color:'white',
  },
  text: {
    color:'orange'
  }
  
  
});

export default ShoppingForm;

