// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCKncHfpGGBHDJPg75zFeqeaNneYh9m8Ks",
  authDomain: "bookmark-app-ceb00.firebaseapp.com",
  projectId: "bookmark-app-ceb00",
  storageBucket: "bookmark-app-ceb00.appspot.com",
  messagingSenderId: "631734711624",
  appId: "1:631734711624:web:9bbebf3ead43e0887e6f7d",
  measurementId: "G-NKDJ2ZTZE3"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);