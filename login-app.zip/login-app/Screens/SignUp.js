import React, {useState} from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity } from 'react-native';


function SignUp({ navigation }) {


  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [firstName, setFirstName] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')

  const SignUp = () => {
    firebase.auth().createUserWithEmailAndPassword(email, password).then(() =>{
        alert("Sign up successfully")
        {navigation.navigate("Login")}
        var db = firebase.firestore();
        db.collection("users").doc(email).set({
          firstName: firstName,
          confirmPassword: confirmPassword,

      })
      .then(() => {
      }).catch((error) => {
        alert(error)})
    }).catch((error) => {
      alert(error)})
  }

  return (
    <View style={styles.container}>

      <TextInput placeholder="Full Name" style={styles.TextInput} onChangeText={(firstName) => setFirstName(firstName)} />
      <TextInput placeholder="Email" style={styles.TextInput} onChangeText={(email) => setEmail(email)} />
      <TextInput placeholder="Password" style={styles.TextInput} onChangeText={(password) => setPassword(password)} />
      <TextInput placeholder="Confirm Password" style={styles.TextInput}  onChangeText={(confirmPassword) => setConfirmPassword(confirmPassword)}/>

     
     <TouchableOpacity
          style={styles.paragraph}
          onPress={() => navigation.navigate('LogIn')}>
         <Text style={styles.Text2} > SignUp</Text>
    
            </TouchableOpacity>
    </View>
  );
}
const styles = StyleSheet.create({
   container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    flexShrink: '0',
    marginLeft: '20%',
    marginRight: '20%',
    marginTop: '20%',
  },
  paragraph: {
      marginTop:20,
    fontSize:15,
    marginLeft:70,
    borderRadius:40,
    borderWidth:1,
    alignSelf:'center',
    backgroundColor:'orange',
    fontWeight:'bold',
    width:200,
    height:50
   
    
  },
  TextInput: {
    borderWidth: '1px',
    width: '300px',
    height: '40px',
    paddingLeft: '10px',
    marginBottom: '10px',
    boxShadow: '1px 1px 2px rgba(0,0,0,0.5)',
    borderRadius:40,
     backgroundColor:'orange',
    
  },
  Text2: {
    marginLeft:70,
    marginTop:12,
    color:'white'

  },
  
});

export default SignUp;