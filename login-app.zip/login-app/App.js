import * as React from 'react';
import 'react-native-gesture-handler';

import navigation from '@react-navigation/native';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { NavigationContainer } from '@react-navigation/native';
import StackNavigavigator from '@react-navigation/native';
import LogIn from './Screens/LogIn';
import SignUp from './Screens/SignUp';
import Display from './Screens/Display'
import ShoppingForm from './Screens/ShoppingForm' 


// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';


const Stack = createNativeStackNavigator();

export default function App() {
  return (
  <NavigationContainer >
      <Stack.Navigator>
        <Stack.Screen name="LogIn" component={LogIn} />
        <Stack.Screen name="SignUp" component={SignUp} />
          <Stack.Screen name="ShoppingForm" component={ShoppingForm} />
      </Stack.Navigator>
    </NavigationContainer>
    
  );
}

const styles = StyleSheet.create({

});

